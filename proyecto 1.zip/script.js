document.getElementById('miFormulario').addEventListener('submit', function(event) {
    var contrasena = document.getElementById('contrasena').value;

    if (contrasena === "322090") {
        // Contraseña correcta, redirige a ow.html
        window.location.href = "ow.html";
    } else {
        // Contraseña incorrecta
        alert("Contraseña incorrecta");
    }

    event.preventDefault(); // Evita que el formulario se envíe



    
});
