$(document).ready(function () {
    // Inicializar el carrusel de Bootstrap
    $('.carousel').carousel({
        interval: 2000 // Puedes ajustar el intervalo según tus preferencias
    });

    // Capturar el evento al cambiar la diapositiva
    $('.carousel').on('slid.bs.carousel', function () {
        // Obtener la fuente de la imagen activa y actualizar la imagen en la sección
        var activeImageSrc = $('.carousel-item.active img').attr('src');
        $('section.awSlider img').attr('src', activeImageSrc);
    });

    // Corregir el enlace del botón Next para evitar problemas con rutas relativas
    $('.carousel-control-next').click(function () {
        $('.carousel').carousel('next');
    });

    // Corregir el enlace del botón Previous para evitar problemas con rutas relativas
    $('.carousel-control-prev').click(function () {
        $('.carousel').carousel('prev');
    });
});
